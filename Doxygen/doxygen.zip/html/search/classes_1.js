var searchData=
[
  ['boyermoore_0',['BoyerMoore',['../classboyer__moore_1_1_boyer_moore.html',1,'boyer_moore']]],
  ['bwt_1',['BWT',['../classbwt_1_1_b_w_t.html',1,'bwt.BWT'],['../classtest__bwt_1_1_b_w_t.html',1,'test_bwt.BWT']]]
];
