var searchData=
[
  ['todasproteinas_0',['todasProteinas',['../classmyseq_1_1_my_seq.html#acd5babfe68c2c3d778009957efaa617c',1,'myseq::MySeq']]],
  ['traduzcodao_1',['traduzCodao',['../classmyseq_1_1_my_seq.html#a66a81476ada8445ce4e9e8e4b170ca5a',1,'myseq::MySeq']]],
  ['traduzcodaoer_2',['traduzCodaoER',['../classmyseq_1_1_my_seq.html#ad6412371288bc9ffb10e32a9ed2afb59',1,'myseq::MySeq']]],
  ['traduzseq_3',['traduzSeq',['../classmyseq_1_1_my_seq.html#ab388c7a77f162831d90b33b1a0b24394',1,'myseq::MySeq']]],
  ['transcricao_4',['transcricao',['../classmyseq_1_1_my_seq.html#a675e987e024ad62ee8b15b8cfd22dc87',1,'myseq::MySeq']]],
  ['trie_5fmatches_5',['trie_matches',['../classtrie_1_1_trie.html#a18e5de7c35d8162e8adf1dbaf3c78f89',1,'trie::Trie']]]
];
