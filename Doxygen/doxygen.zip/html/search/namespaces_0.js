var searchData=
[
  ['debruijn_0',['debruijn',['../namespacedebruijn.html',1,'']]]
];
