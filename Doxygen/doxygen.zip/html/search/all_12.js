var searchData=
[
  ['valida_0',['valida',['../classmyseq_1_1_my_seq.html#a32c024b61e71cd3bc61231616d45e0a2',1,'myseq::MySeq']]],
  ['validaer_1',['validaER',['../classmyseq_1_1_my_seq.html#a05f4700160b38cd5a1a06623de450ae5',1,'myseq::MySeq']]],
  ['vec_5fto_5fpwm_2',['vec_to_pwm',['../class_e_a_motifs_1_1_e_a_motifs_real.html#aa6ae463bb504a85617ae1eb72f2119ca',1,'EAMotifs::EAMotifsReal']]]
];
