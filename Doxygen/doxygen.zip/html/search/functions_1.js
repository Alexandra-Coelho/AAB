var searchData=
[
  ['active_5freactions_0',['active_reactions',['../classmetabolicnetwork_1_1_metabolic_network.html#afc03119b4f59328ed79baa4028eeb916',1,'metabolicnetwork::MetabolicNetwork']]],
  ['add_5fedge_1',['add_edge',['../classdebruijn_1_1_de_bruijn_graph.html#a1d433a607414841e6ea95e19502b0789',1,'debruijn.DeBruijnGraph.add_edge()'],['../classmygraph_1_1_my_graph.html#aa580dc56262eaf4f33824cb9ed1e5473',1,'mygraph.MyGraph.add_edge()'],['../classmygraph__custos_1_1_my_graph__custo.html#a470b3447be940176fcf3f8aefeb14c3f',1,'mygraph_custos.MyGraph_custo.add_edge()']]],
  ['add_5fvertex_2',['add_vertex',['../classmygraph_1_1_my_graph.html#a291563c79d388ab92d562888bcd1a218',1,'mygraph.MyGraph.add_vertex()'],['../classmygraph__custos_1_1_my_graph__custo.html#a4df98dba9d0a9356aaad2173ad3b40ee',1,'mygraph_custos.MyGraph_custo.add_vertex()']]],
  ['add_5fvertex_5ftype_3',['add_vertex_type',['../classmetabolicnetwork_1_1_metabolic_network.html#ac93755de0dd3f75d92904f5f5571ceac',1,'metabolicnetwork::MetabolicNetwork']]],
  ['alfabeto_4',['alfabeto',['../classmyseq_1_1_my_seq.html#a1c98587061895b93747bb86087f6e20f',1,'myseq::MySeq']]],
  ['all_5fdegrees_5',['all_degrees',['../classmygraph_1_1_my_graph.html#a9d91d367785f8e0a2feda711111e57be',1,'mygraph::MyGraph']]],
  ['all_5fproduced_5fmetabolites_6',['all_produced_metabolites',['../classmetabolicnetwork_1_1_metabolic_network.html#a720db429b21e4518670b1eccd0d0fe0c',1,'metabolicnetwork::MetabolicNetwork']]],
  ['applyseq_7',['applySeq',['../classautomata_1_1_automata.html#a69248dc9c932bef13b367f291604a33a',1,'automata::Automata']]]
];
